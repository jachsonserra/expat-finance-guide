# 5. Banking & Currency Management

Choosing the right bank account and managing multiple currencies can save you hundreds of euros per year in fees and give you peace of mind.

This chapter covers:
- Traditional vs digital banks in Europe
- How to send money home cheaply
- Dealing with currency fluctuations
- Protecting yourself from fraud

## Traditional Banks vs Digital Banks (Neobanks)

### Traditional Banks (Deutsche Bank, Santander, Barclays, etc.)
**Pros:**
- Physical branches (useful for notarizing documents, depositing cash)
- Often required for certain visas or rental contracts
- Long‑standing reputation

**Cons:**
- High fees (monthly account fees, transaction fees, international transfer fees)
- Poor exchange rates
- Outdated online banking

### Digital Banks (Revolut, N26, Wise, Bunq, etc.)
**Pros:**
- Low or zero monthly fees
- Real‑time notifications
- Multi‑currency accounts
- Better exchange rates (often near mid‑market)
- Easy to open (often no residency requirement)

**Cons:**
- No physical branches (cash deposits may be difficult)
- Customer service can be slow (chat‑only)
- Some have monthly limits on free transactions

### Recommendation for Expats
**Open two accounts:**
1. **A local traditional account** for receiving salary (if required) and dealing with official paperwork.
2. **A digital multi‑currency account** (Revolut or Wise) for day‑to‑day spending, currency exchange, and sending money internationally.

## How to Open a Bank Account as an Expat

Requirements vary by country, but generally you’ll need:
- Passport
- Proof of address (rental contract, utility bill)
- Tax identification number (local TIN)
- Proof of employment or student status

**Tip:** If you’re struggling with proof of address, ask your employer for a letter confirming your employment and address. Some digital banks (N26, Revolut) accept temporary accommodation addresses.

## Sending Money Home: The Cheapest Ways

The worst thing you can do is use your bank’s international transfer service. They charge high fees and give poor exchange rates.

### Option 1: Wise (formerly TransferWise)
- Transparent fees (shown upfront)
- Mid‑market exchange rate
- Fast (1–2 business days)
- Can hold balances in 50+ currencies

**When to use:** Regular transfers to family, paying bills in your home currency.

### Option 2: Revolut
- Free transfers up to a monthly limit (varies by plan)
- Exchange at interbank rate on weekdays (0.5% markup on weekends)
- Instant transfers to other Revolut users

**When to use:** Small, frequent transfers; spending abroad.

### Option 3: CurrencyFair or OFX
- Better for large amounts (>€10k)
- Can set target exchange rates (limit orders)
- Often lower fees for big transfers

**When to use:** Moving savings, buying property abroad.

### Step‑by‑Step: Sending €1,000 to USD
1. **Bank transfer:** Fee €25 + 3% markup → you lose ~€55.
2. **Wise:** Fee €5.64 + 0.42% markup → you lose ~€9.82.
3. **Revolut (weekday):** Fee €0 + 0% markup → you lose €0.

The difference is real.

## Managing Multiple Currencies

If you earn in euros but have debts in dollars, or you’re paid in pounds but live in Spain, you need a strategy.

### The “Currency Bucket” Method
1. **Income bucket:** Where your salary lands (local currency).
2. **Spending bucket:** Where you keep money for daily expenses (local currency).
3. **Savings bucket:** Where you accumulate euros for goals.
4. **Home bucket:** Where you keep money for family/obligations in home currency.

**Tool:** Use Wise or Revolut multi‑currency accounts to hold separate balances. Set up automatic transfers when exchange rates are favorable.

### Hedging Against Fluctuations
If you’re paid in a volatile currency (e.g., GBP post‑Brexit), consider:
- **Converting a fixed percentage each month** (e.g., 50% of salary) regardless of rate. This averages out ups and downs.
- **Using a limit order** (Wise, CurrencyFair) to automatically convert when the rate hits your target.
- **Keeping an emergency fund in the stable currency** (euros) to cover 3 months of expenses.

## Protecting Yourself from Fraud

European banks have strong consumer protections, but you still need to be vigilant.

### Common scams targeting expats:
- **Phishing emails** pretending to be from your bank (check the sender’s domain).
- **Fake rental deposits** (never transfer money without seeing the apartment and contract).
- **ATM skimming** (use ATMs inside banks, cover your PIN).

### Safety rules:
1. **Enable two‑factor authentication** on all banking apps.
2. **Use a password manager** (Bitwarden, 1Password).
3. **Set up transaction notifications** for every payment.
4. **Never share your PIN or online banking password**—banks will never ask for them.

## What to Do If Your Bank Account Is Frozen

Sometimes banks freeze accounts for “suspicious activity”—common when you receive large international transfers.

**Steps to unfreeze:**
1. **Call the bank immediately.** Have your passport and proof of funds ready.
2. **Provide documentation:** payslips, contracts, tax returns.
3. **Be polite but persistent.** Ask for a timeline.
4. **Keep a backup account** with another bank with enough cash for 1–2 months.

## Action Steps This Week
1. **Open a digital multi‑currency account** (Revolut or Wise) if you don’t have one.
2. **Compare your last international transfer**—calculate how much you lost in fees and exchange rate markup.
3. **Set up transaction notifications** on all your accounts.
4. **Create a “currency bucket” plan** for your income.

Next, we’ll dive into saving and investing—how to grow your money even with a modest income.