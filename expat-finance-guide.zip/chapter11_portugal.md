# 11. Portugal: NHR, Digital Nomads, and Affordable Living

Portugal combines low cost of living with attractive tax regimes for newcomers.

## NHR (Non‑Habitual Resident) Regime

- **What it is:** A 10‑year tax benefit for new residents.
- **Eligibility:** Haven’t been tax resident in Portugal in the previous 5 years.
- **Benefits:**  
  - **Employment income:** 20% flat tax (instead of progressive 14.5–48%).  
  - **Professional income** (high‑value activities): 20% flat tax.  
  - **Pensions:** 10% flat tax.  
  - **Foreign‑source income** (dividends, interest, rents): Often tax‑free if taxed at source.
- **Deadline:** Apply within 12 months of becoming tax resident.

**Action:** If you’re eligible, hire a Portuguese tax advisor to handle the application. The paperwork is worth the savings.

## Digital Nomad Visa (D8)

- **Requirements:** €3,040/month income (2026), remote work contract or freelance clients.
- **Tax status:** You can opt for NHR if you meet criteria.
- **Duration:** 1 year, renewable for 5 years, then permanent residency possible.

## Cost of Living

- **Lisbon:** €1,000–€1,500/month for a one‑bedroom apartment. Rising fast.
- **Porto:** €800–€1,200/month.
- **Algarve (Faro, Lagos):** €700–€1,100/month.
- **Coimbra/Braga:** €600–€900/month.

**Budget example (Porto, single):**  
Rent: €900  
Groceries: €200  
Utilities: €120  
Transport: €40  
Health insurance: €50  
Total: ~€1,310

## Tax System (Without NHR)

- **Progressive rates:** 14.5–48% (2026).
- **Social security:** 11% from employee, 23.75% from employer.
- **Freelancers (trabalhadores independentes):** 21.4% social security on 70% of income (simplified regime).

**Tip:** Even without NHR, Portugal’s taxes are lower than many EU countries for middle incomes.

## Renting

- **Deposit (caução):** One to two months’ rent.
- **Agent fee:** One month’s rent + VAT (23%), usually split between landlord and tenant.
- **Lease duration:** Minimum 1 year, automatically renews.
- **Rental contract registration:** Mandatory. Landlord must register with Finanças.

**Warning:** The rental market is competitive. Have your documents ready (NIF, proof of income, passport).

## Banking

- **Traditional (Caixa Geral de Depósitos, Millennium):** Poor English support, high fees.
- **Digital (ActivoBank, Revolut, N26):** ActivoBank (Millennium’s digital brand) is free and English‑friendly.
- **Savings:** Trade Republic (4%) available. Portuguese banks offer near‑zero interest.

## Health Insurance

- **National Health Service (SNS):** Free for residents, but waits are long.
- **Private insurance (Multicare, Médis, AdvanceCare):** €30–€100/month. Covers private hospitals and faster appointments.
- **Recommendation:** Get private insurance, especially if you’re not yet eligible for SNS.

## Pension Planning

- **State pension:** Requires 15 years of contributions. Formula based on average lifetime earnings.
- **Private pension (PPR):** Tax‑deductible up to €2,000/year (20% of contributions). But funds have high fees and limited choices.
- **Better path:** Open a brokerage account (Degiro, Interactive Brokers) and invest in ETFs. Keep PPR only for the tax deduction if you’re in a high tax bracket.

## Liability Insurance (Seguro de Responsabilidade Civil)

€40–€80/year. Often bundled with home insurance. Get it—especially if you rent.

## Checklist

- [ ] Obtain NIF (tax number) before arriving (via consulate or intermediary).
- [ ] Open a bank account (ActivoBank or Revolut).
- [ ] Register as resident at the town hall (câmara municipal).
- [ ] Apply for NHR if eligible (hire a lawyer).
- [ ] Get private health insurance.
- [ ] Set up a brokerage account for long‑term investments.
- [ ] Learn basic Portuguese—it helps with bureaucracy.

## Resources

- **Portal das Finanças:** Tax authority website (use Chrome translate).
- **Expatica Portugal:** English‑language guides.
- **Reddit:** r/Portugal, r/PortugalExpats.
- **Facebook groups:** “Expats in Lisbon/Porto”.

Next: United Kingdom.