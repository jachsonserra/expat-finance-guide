# 8. Insurance You Actually Need

Insurance is boring until you need it. As an expat, you’re often navigating unfamiliar systems where a single mistake can cost thousands.

This chapter will help you:
- Identify mandatory insurance in your country
- Decide which optional coverage is worth it
- Avoid over‑ or under‑insuring

## The Hierarchy of Insurance Needs

Think of insurance as a pyramid:

```
        ╱╲
       ╱  ╲      Top: Nice‑to‑haves (travel, gadget, pet)
      ╱    ╲
     ╱      ╲    Middle: Important (household contents, income protection)
    ╱________╲
   ╱          ╲   Base: Must‑haves (health, liability, legally required)
```

Start at the base. Only add higher layers if you have the budget and risk exposure.

## Health Insurance (The Non‑Negotiable)

In most EU countries, health insurance is mandatory. The system varies:

### Germany
- **Public insurance** (Gesetzliche Krankenversicherung): Covers ~90% of residents. Premium is 14.6% of gross salary, split 50/50 with employer. Family members included free.
- **Private insurance** (Private Krankenversicherung): Available if you earn above €69,300 (2026 threshold). Cheaper when young, but premiums rise with age and are individual (no family coverage).
- **Recommendation:** Stay public unless you’re a high‑earner with no dependents.

### Spain
- **Public system** (Seguridad Social): Covers employees and their families. Funded via social security contributions (6.35% from employee, 29.9% from employer).
- **Private insurance:** Often used for faster specialist access. Costs €50–€150/month.
- **Recommendation:** If you’re employed, you’re automatically covered by public. Consider private for dental and shorter wait times.

### Portugal
- **National Health Service** (SNS): Free for residents, but wait times can be long.
- **Private insurance:** Common among expats. Plans start at €30/month.
- **Recommendation:** Get private insurance if you’re not eligible for SNS or want comprehensive coverage.

### United Kingdom
- **National Health Service** (NHS): Free at point of use, funded by taxes.
- **Private insurance:** Optional, for faster access and private rooms. Often provided as a workplace benefit.
- **Recommendation:** NHS is sufficient for most. If your employer offers private insurance, take it.

**Action:** Verify your coverage. If you’re freelance, you must arrange your own—compare providers using websites like Check24 (DE), Comparativa (ES), or MoneySuperMarket (UK).

## Liability Insurance (Haftpflichtversicherung / Responsabilidad Civil)

This is the most overlooked yet critical insurance for expats.

**What it covers:** If you accidentally cause damage to someone else’s property or person. Examples:
- You slip on a wet floor in a supermarket and break a display.
- Your child scratches a neighbor’s car.
- You flood the apartment below by leaving the tap on.

**Cost:** €50–€100/year for €10–€50 million coverage.

**Verdict:** Get it immediately. It’s cheap and can save you from bankruptcy.

## Household Contents Insurance (Hausratversicherung / Seguro de Hogar)

Covers your belongings against theft, fire, water damage.

**What’s included:** Furniture, electronics, clothing, jewelry (up to a limit).
**What’s not:** Wear and tear, intentional damage.

**Cost:** €50–€150/year depending on coverage and location.

**Verdict:** Worth it if you own expensive electronics or live in a high‑risk area. If you’re renting a furnished room with few possessions, you might skip it.

## Legal Protection Insurance (Rechtsschutzversicherung)

Covers legal fees if you need to sue or are sued.

**Typical scenarios:** Tenant‑landlord disputes, employment conflicts, traffic accidents.

**Cost:** €150–€300/year.

**Verdict:** Consider if you’re a freelancer, landlord, or frequently engage in contracts. For most employees, optional.

## Income Protection (Berufsunfähigkeitsversicherung)

Pays a monthly income if you become unable to work due to illness or injury.

**Cost:** 2–4% of your income, depending on age and health.

**Verdict:** Crucial for freelancers and sole breadwinners. If you have a stable job with sick pay, you may rely on employer benefits.

## Travel Insurance

If you travel frequently (especially outside the EU), a yearly multi‑trip policy is cheaper than buying per trip.

**Coverage:** Medical emergencies, trip cancellation, lost luggage.

**Cost:** €50–€150/year.

**Verdict:** Worth it if you travel more than twice a year.

## How to Choose an Insurance Provider

1. **Use comparison sites:** Check24 (Germany), Comparativa (Spain), MoneySavingExpert (UK).
2. **Check English‑language support.** Many providers have English‑speaking customer service.
3. **Look for flexibility:** Can you increase coverage later? Cancel easily?
4. **Read reviews** on Trustpilot or local expat forums.

## Common Pitfalls

- **Underinsuring:** Setting coverage limits too low (e.g., €10k for household contents when you own €30k worth of stuff).
- **Overlapping coverage:** Your credit card may already include travel insurance—check before buying duplicate.
- **Ignoring exclusions:** Pre‑existing conditions often excluded from health/travel insurance.
- **Forgetting to update:** When you move, get married, or buy expensive items, update your policies.

## Action Steps This Month

1. **Verify your health insurance** is active and covers your needs.
2. **Buy liability insurance** if you don’t have it (do it today).
3. **Assess your belongings**—do you need household contents insurance?
4. **Review any workplace benefits** (group health, disability, travel).

Insurance is about peace of mind. Next, we’ll dive into country‑specific tips for Germany, Spain, Portugal, and the UK.