# 9. Germany: Navigating Taxes, Renting, and Retirement

Germany is efficient, bureaucratic, and full of financial opportunities—if you know the rules.

## Tax Classes (Lohnsteuerklasse)

Your tax class determines how much income tax is withheld each month. Choose wisely:

- **Class I:** Single, divorced, or permanently separated.
- **Class II:** Single parent (get a child allowance).
- **Class III/V:** Married couples. The higher earner takes III (lower withholding), the lower earner takes V (higher withholding). Optimizes cash flow.
- **Class IV:** Married, both similar income (default).
- **Class IV with factor:** Adjusts withholding to approximate annual tax liability.

**Action:** If you’re married, use the official tax calculator (Bundesministerium der Finanzen) to compare III/V vs IV. Submit a “Lohnsteuer‑Ermäßigungsantrag” to change classes.

## Renting in Germany

- **Deposit (Kaution):** Up to three months’ cold rent. Must be held in a separate bank account.
- **Additional costs (Nebenkosten):** Heating, water, garbage, building maintenance. Usually paid monthly as an advance, settled annually.
- **Index rent (Indexmiete):** Rent can increase annually based on inflation. Maximum 15% over three years.
- **Termination notice:** Three months for tenants, longer for landlords (6–9 months if you’ve lived there long).

**Tip:** Use a “Mieterverein” (tenant association) for legal support (€50–€100/year). They help with disputes and contract reviews.

## Retirement Planning

- **State pension (Gesetzliche Rentenversicherung):** You need 5 years of contributions to qualify for any payout. The formula is complex; expect 40–50% of your average income.
- **Company pension (Betriebliche Altersvorsorge):** Often with employer matching. Contribute at least enough to get the full match.
- **Private pension (Riester/Rürup):** Government‑subsidized but restrictive. Consider instead: **ETF‑based pension plans** (ETF‑Sparplan) via a broker like Trade Republic.

**Recommended split:**  
- 10% to company pension (if matched)  
- 5–10% to private ETF savings  
- Rely on state pension as a bonus, not a foundation.

## Banking

- **Current account (Girokonto):** Traditional banks charge €5–€15/month. Free alternatives: N26, DKB, Comdirect.
- **Savings account:** Use Trade Republic (4% on uninvested cash) or Raisin for term deposits.
- **Cash is still king** in many small shops and restaurants. Keep €50–€100 in your wallet.

## Health Insurance

- **Public (GKV):** 14.6% of gross salary, split 50/50 with employer. Covers spouse and children free.
- **Private (PKV):** If you earn above €69,300 (2026), you can switch. Be careful—once you leave public, it’s hard to return.
- **Dental:** Basic coverage included. Consider supplemental dental insurance (Zahnzusatzversicherung) for crowns/implants.

## Liability Insurance (Haftpflichtversicherung)

Non‑negotiable. €60/year for €50 million coverage. Use Check24 to compare.

## Quick Checklist

- [ ] Choose correct tax class (finanzamt.de)
- [ ] Register at the Bürgeramt within 14 days of arrival
- [ ] Open a free bank account (N26/DKB)
- [ ] Get liability insurance (Haftpflicht)
- [ ] Join a tenant association (Mieterverein) if renting
- [ ] Set up a ETF savings plan (€50/month minimum)
- [ ] Verify your health insurance status

## Resources

- **Tax office (Finanzamt):** Provides free brochures in English.
- **Consumer advice (Verbraucherzentrale):** Cheap consultations.
- **Expatica Germany:** English‑language guides.
- **Reddit:** r/germany, r/Finanzen (use DeepL for translation).

Next: Spain.