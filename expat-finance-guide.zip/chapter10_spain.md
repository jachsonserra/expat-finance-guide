# 10. Spain: Autónomos, Regional Taxes, and Cost of Living

Spain offers sunshine, a slower pace, and a tax system with surprising complexity.

## Tax System (IRPF)

- **Progressive rates:** 19–47% (2026), depending on region.
- **Withholding (retención):** Employees have ~15% withheld monthly. Freelancers (autónomos) make quarterly prepayments.
- **Regional differences:** Catalonia, Madrid, Basque Country have their own rates and deductions.
- **Beckham Law (Ley Beckham):** For foreign hires—flat 24% tax on income up to €600k for the first 6 years. Must apply within 6 months of arrival.

**Action:** If you earn >€60k and are eligible, apply for Beckham Law. Otherwise, use a “gestor” (tax advisor) to navigate deductions.

## Freelancers (Autónomos)

- **Monthly fee (cuota):** €300–€600 depending on coverage. Includes health insurance and pension contributions.
- **Quarterly VAT (IVA):** 21% standard rate, but you can deduct business‑related IVA.
- **Simplified regime (Régimen Simplificado):** For turnover <€250k/year. Fewer paperwork.
- **Recommendation:** Join a “colectivo” (freelancer association) for group health insurance and legal support.

## Renting

- **Deposit (fianza):** One month’s rent (by law). Landlords often ask for two.
- **Agent fee:** Usually one month’s rent + VAT (21%), paid by tenant.
- **Utilities:** Not always included. Ask for “gastos incluidos” if you want predictability.
- **Rental contract:** Minimum 5 years for individuals, 7 for companies. You can leave with 30 days’ notice after 6 months.

**Tip:** Use Idealista or Fotocasa to search. Avoid scams—never wire money before seeing the property.

## Cost of Living by Region

- **Madrid/Barcelona:** €1,200–€1,800/month for a one‑bedroom apartment. High transportation costs.
- **Valencia/Alicante:** €700–€1,200/month. Popular with digital nomads.
- **Andalusia (Málaga, Sevilla):** €600–€1,000/month. Lower salaries but lower costs.

**Budget example (Valencia, single):**  
Rent: €800  
Groceries: €250  
Utilities: €120  
Transport: €40  
Health insurance: €70  
Total: ~€1,280

## Banking

- **Traditional banks (Santander, BBVA):** High fees, poor English support.
- **Digital banks (N26, Revolut, Openbank):** Free, English‑friendly.
- **Savings accounts:** MyInvestor offers 2–3% on deposits. Trade Republic also available.

## Health Insurance

- **Public (Seguridad Social):** Covers employees and autónomos (via monthly fee). Quality varies by region.
- **Private (Sanitas, Adeslas, DKV):** €50–€150/month. Faster access, includes dental.
- **Recommendation:** If you’re autónomo, you’re already covered by public. Add private for dental and specialists.

## Pension System

- **State pension:** Requires 15 years of contributions (minimum). Formula based on last 25 years’ contributions.
- **Private plans (Planes de Pensiones):** Tax‑deductible up to €1,500/year, but funds have high fees and limited investment options.
- **Better alternative:** Open a brokerage account (Degiro, Interactive Brokers) and invest in ETFs. More control, lower fees.

## Liability Insurance (Seguro de Responsabilidad Civil)

€50–€100/year. Covers accidental damage to third parties. Often bundled with home insurance.

## Checklist

- [ ] Apply for NIE (foreigner tax number) at the police station.
- [ ] Open a bank account (N26 or Openbank).
- [ ] Register at the town hall (empadronamiento).
- [ ] Choose between autónomo or employee status.
- [ ] Get private health insurance if you want faster care.
- [ ] Set up a brokerage account for long‑term savings.
- [ ] Find a “gestor” for tax filings (worth the €300/year).

## Resources

- **Agencia Tributaria:** Tax agency website (English section).
- **Expatica Spain:** Practical guides.
- **Reddit:** r/Spain, r/ESLegal.
- **Facebook groups:** “Expats in Barcelona/Madrid/Valencia”.

Next: Portugal.