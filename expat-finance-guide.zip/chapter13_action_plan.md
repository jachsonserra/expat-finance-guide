# 13. Your 90‑Day Financial Action Plan

Knowledge without action is just trivia. This chapter turns everything you’ve learned into a step‑by‑step, week‑by‑week plan.

## Week 1–2: Foundation
- **Day 1–3:** Set up your budget template. Enter last month’s expenses.
- **Day 4–5:** Open a high‑yield savings account (Trade Republic or local equivalent). Transfer your first 5% savings.
- **Day 6–7:** Buy liability insurance (if you don’t have it). Takes 20 minutes online.

## Week 3–4: Systems
- **Day 8–10:** Automate your savings. Set up a standing order for payday.
- **Day 11–14:** Review your bank accounts. Close any with high fees. Open a digital multi‑currency account (Wise/Revolut) if needed.
- **Day 15–21:** Check your tax residency status. Gather documents for tax filing (if due soon).

## Week 5–8: Optimization
- **Week 5:** Audit your subscriptions and recurring bills. Cancel at least one.
- **Week 6:** Compare your last international transfer. Calculate how much you lost. Set up a Wise account for next time.
- **Week 7:** Review your insurance coverage (health, liability, household). Fill gaps.
- **Week 8:** Open a brokerage account (Trade Republic, Degiro, or local). Invest €50 in a global ETF.

## Week 9–12: Growth
- **Week 9:** Increase your savings rate by 1% (from 5% to 6%).
- **Week 10:** Set up a second savings bucket for a specific goal (e.g., €500 for a weekend trip).
- **Week 11:** Learn one new investing concept (e.g., dollar‑cost averaging, compound interest).
- **Week 12:** Review your progress. Celebrate wins, adjust where needed.

## Monthly Maintenance (From Month 4 Onward)
1. **First weekend of the month:** Update your budget, check account balances.
2. **Second weekend:** Transfer savings, invest according to your plan.
3. **Third weekend:** Read one personal finance article or listen to a podcast.
4. **Fourth weekend:** Reflect on your financial mindset. Journal one thing you’re grateful for.

## Quarterly Check‑In
Every three months, ask:
- Am I closer to my goals than 90 days ago?
- Has my income or expenses changed significantly?
- Do I need to adjust my budget categories?
- Is my emergency fund still sufficient?

**Use the spreadsheet templates** to track your progress. The “Expense Tracker” has a tab for monthly summaries.

## When Life Throws a Curveball
- **Unexpected expense:** Use your emergency fund, then rebuild.
- **Income drop:** Revisit your budget, cut discretionary spending first.
- **Market downturn:** Keep investing. History shows markets recover.
- **Feeling overwhelmed:** Go back to Chapter 1. Remind yourself why you started.

## The 1% Rule
Improve your financial health by just 1% each week. In 90 days, you’ll be 12% better off. Small, consistent actions beat grand plans.

Next: Staying motivated and finding support.