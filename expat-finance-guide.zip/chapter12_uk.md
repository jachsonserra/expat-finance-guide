# 12. United Kingdom: NHS, ISAs, and Post‑Brexit Realities

The UK offers a straightforward financial system with strong consumer protections, but post‑Brexit rules have added complexity for EU nationals.

## Tax System

- **Personal allowance:** First £12,570 (≈€14,500) tax‑free (2026/27).
- **Basic rate:** 20% on income up to £50,270.
- **Higher rate:** 40% up to £150,000.
- **Additional rate:** 45% above £150,000.
- **National Insurance:** 12% on earnings between £12,570–£50,270, 2% above.

**Action:** Use the government’s tax calculator to estimate your take‑home. If you have multiple incomes, register for self‑assessment.

## ISAs (Individual Savings Accounts)

The UK’s best tax‑advantaged savings vehicle.

- **Types:**  
  - **Cash ISA:** Savings account, tax‑free interest.  
  - **Stocks & Shares ISA:** Investment account, all gains and dividends tax‑free.  
  - **Lifetime ISA:** For first‑time home buyers or retirement, 25% government bonus.
- **Annual allowance:** £20,000 (2026/27) across all ISAs.
- **No tax reporting required.** Withdrawals are tax‑free.

**Recommendation:** Open a Stocks & Shares ISA with a low‑cost provider (Vanguard Investor UK, Trading 212, InvestEngine). Invest in a global ETF (VWRL) and max out your allowance if possible.

## Pension System

- **State pension:** Requires 10 qualifying years for any payout, 35 years for full (£10,600/year in 2026). Check your National Insurance record online.
- **Workplace pension:** Auto‑enrolment mandatory for employees aged 22–66 earning >£10,000/year. Employer contributes at least 3%, you contribute 5%.
- **Private pension (SIPP):** Self‑invested personal pension. Tax‑relief on contributions (20% basic rate added automatically). Access from age 57.

**Strategy:** Contribute enough to workplace pension to get full employer match, then open a SIPP for additional retirement savings.

## Healthcare (NHS)

- **Free at point of use** for residents (funded via taxes).
- **Prescriptions:** £9.90 per item (England), free in Scotland, Wales, Northern Ireland.
- **Dental:** Subsidised but often long waits. Private dental insurance common.
- **Private health insurance:** Often provided as a workplace perk. Useful for faster specialist access.

**Note:** As an EU national, you may need to pay the Immigration Health Surcharge (IHS) as part of your visa application—currently £1,035/year.

## Renting

- **Deposit:** Maximum 5 weeks’ rent (if annual rent <£50,000). Must be placed in a government‑backed protection scheme.
- **Tenancy fees:** Banned for tenants (except rent, deposit, default fees).
- **Contract types:** Most are “assured shorthold tenancies” (6–12 months).
- **Rent increases:** Landlord must give one month’s notice and can only increase once per year.

**Tip:** Use SpareRoom, Rightmove, Zoopla. Always verify the landlord’s identity and that the deposit is protected.

## Cost of Living

- **London:** £1,500–£2,500/month for a one‑bedroom flat. Transport expensive.
- **Manchester/Birmingham:** £800–£1,200/month.
- **Edinburgh:** £900–£1,400/month.
- **Smaller cities (Leeds, Bristol):** £700–£1,100/month.

**Budget example (Manchester, single):**  
Rent: £950  
Groceries: £200  
Utilities: £150  
Transport: £70  
Phone/internet: £40  
Total: ~£1,410

## Banking

- **Traditional (Barclays, HSBC, Lloyds):** Free current accounts, but overdraft fees high.
- **Digital (Monzo, Starling, Revolut):** Full‑featured, instant notifications, budgeting tools.
- **Savings accounts:** Interest rates 3–5% (2026) for easy‑access accounts (Chip, Marcus). Use MoneySavingExpert to compare.

**Recommendation:** Open a Monzo or Starling account as your main, and a separate savings account for emergency fund.

## Liability Insurance

- **Home contents insurance** often includes liability cover.
- **Standalone personal liability insurance** costs £30–£60/year.
- **Important:** If you’re a tenant, your landlord’s building insurance does not cover your belongings or liability.

## Brexit Implications for EU Nationals

- **Settled status:** If you arrived before 31 Dec 2020, apply for settled or pre‑settled status.
- **New arrivals:** Need a visa (Skilled Worker, Health & Care, etc.). Financial requirements vary.
- **Banking:** EU‑based banks may close your accounts if you’re no longer resident in the EU. Switch to a UK bank.
- **Investments:** ISAs are only available to UK residents. If you leave, you can keep the account but can’t contribute further.

## Checklist

- [ ] Apply for National Insurance number (if you don’t have one).
- [ ] Open a UK bank account (Monzo/Starling).
- [ ] Register with a GP (doctor) for NHS access.
- [ ] Enrol in workplace pension (if eligible).
- [ ] Open a Stocks & Shares ISA (Vanguard UK).
- [ ] Protect your rental deposit (ask for certificate).
- [ ] Check your visa/residency status regularly.

## Resources

- **GOV.UK:** Official government services (tax, visas, benefits).
- **MoneySavingExpert:** Best deals on banking, insurance, utilities.
- **Reddit:** r/UKPersonalFinance, r/HousingUK.
- **Facebook groups:** “Expats in London/Manchester/Edinburgh”.

Next: Your 90‑Day Action Plan.