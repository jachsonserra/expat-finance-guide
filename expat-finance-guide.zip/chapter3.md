# 3. Your Monthly Budget That Actually Works

A budget isn’t a straitjacket. It’s a map. It shows you where you are, where you want to go, and how to get there without running out of fuel.

Most budgeting advice fails for expats because it assumes:
- Your income is stable and in one currency
- You have years of spending data to base averages on
- You know what a “normal” grocery bill looks like

Let’s throw that out. We’ll build a budget that adapts to your reality.

## The 3‑Category System

Forget 20+ detailed categories. You only need three:

1. **Fixed Essentials** (50–60% of income)
   - Rent/mortgage
   - Health insurance
   - Utilities (electricity, gas, water)
   - Internet/phone
   - Transport (monthly pass)
   - Minimum debt payments
   - Subscriptions you can’t live without (maybe Netflix, but not five streaming services)

2. **Variable Essentials** (20–30% of income)
   - Groceries
   - Dining out
   - Additional transport (taxis, extra train tickets)
   - Healthcare (pharmacy, copays)
   - Household items (toiletries, cleaning supplies)
   - Necessary clothing (replacements, not fashion)

3. **Discretionary & Goals** (20–30% of income)
   - Entertainment
   - Travel
   - Shopping for wants
   - Gifts & donations
   - Savings (emergency fund, retirement, investments)
   - Big goals (down payment, career change fund)

### How to allocate
If you’re new to budgeting, start with:
- 60% Fixed Essentials
- 25% Variable Essentials  
- 15% Discretionary & Goals

If your fixed costs are lower, shift more to savings. If they’re higher (common in expensive cities), you may need to adjust variable/discretionary.

## Step‑by‑Step: Setting Up Your Budget

### 1. Gather Your Numbers
Open your bank statements (last 3 months). For each category, calculate the **average monthly spend**. Use the template we provided (Monthly Budget Spreadsheet) or a simple notebook.

*Example:*
- Rent: €850
- Health insurance: €110
- Groceries: €280
- Dining out: €120
- Transport: €65
- etc.

### 2. Enter Your Averages
Put these numbers in the “Actual” column of your template. Don’t judge—just record.

### 3. Set Your Targets
Now, decide what you **want** to spend. Be realistic. If you’ve been spending €300/month on dining out, cutting to €50 will fail. Try €200 first.

Enter these targets in the “Budgeted” column.

### 4. Track As You Go
Each week, open the template and log your spending. The “Difference” column will show whether you’re over or under.

**Pro tip:** Use a notes app on your phone to jot down purchases during the day, then transfer to the sheet once a week.

## Handling Multiple Currencies

If you earn in USD but spend in EUR:

1. **Pick a primary currency** (the one you pay most bills in). For most expats in Europe, that’s euros.
2. **Convert income once a month** using the mid‑month exchange rate (or the rate you actually get from your bank).
3. **Record everything in the primary currency**. The template includes a column for “Currency” if you want to note original amounts.

Example:  
Income: $3,000 at exchange rate 1.10 → €2,727  
Rent: €850  
Groceries: €280  
… etc.

## The “Rollover” Mindset

Some months you’ll spend less on groceries, more on travel. That’s fine. The budget isn’t broken.

Instead of “I failed,” think “I’ll adjust next month.”  
If you underspend in a category, let the surplus roll over to next month (or move it to savings).  
If you overspend, borrow from another category **before** dipping into savings.

## Automating What You Can

Set up automatic transfers for:
- Fixed essentials (rent, insurance)
- Savings (right after you get paid—pay yourself first)
- Debt payments

This reduces decision fatigue and ensures bills are paid on time.

## When Your Income Is Irregular

Freelancers, contractors, and seasonal workers: your budget needs a buffer.

1. **Calculate your baseline monthly need** (all Fixed + Variable Essentials).
2. **Build a “income smoothing” account**. In good months, deposit extra. In lean months, withdraw to cover baseline.
3. **Budget based on your rolling 3‑month average income**, not the latest paycheck.

The template includes a separate sheet for variable‑income planning.

## Common Pitfalls & Solutions

- **“I forget to track”** → Schedule a weekly 15‑minute money date. Sunday evening works for many.
- **“Categories don’t fit”** → Rename them. The template is fully customizable.
- **“I feel restricted”** → Include a “fun money” category with no strings attached. Budgets need breathing room.
- **“My partner doesn’t budget”** → Use a shared sheet (Google Sheets works well) and review together monthly.

## Next Steps

Your budget is now set up. In the next chapter, we’ll tackle the scariest topic: taxes. You’ll learn how to estimate what you owe, find deductions, and decide when to hire a professional.

But first, take a week to live with this budget. Don’t change anything—just observe. The goal isn’t perfection; it’s awareness.