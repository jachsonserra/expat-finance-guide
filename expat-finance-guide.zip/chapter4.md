# 4. Taxes Made Simple (Not Scary)

Taxes in Europe are complicated—but not incomprehensible. You don’t need to become a tax expert. You just need to know enough to avoid overpaying and stay compliant.

This chapter will give you a framework for understanding your tax obligations, finding deductions, and deciding when to hire a professional.

## The Big Picture: How European Taxes Work

Most European countries use a **progressive tax system**: the more you earn, the higher the percentage you pay on each additional euro.

Key concepts:
- **Tax residency**: Usually determined by where you live 183+ days per year. As an expat, you may be tax‑resident in both your home country and your host country (double taxation treaties often apply).
- **Taxable income**: Your gross income minus certain deductions (social security, pension contributions, business expenses).
- **Withholding tax**: Many employers deduct taxes automatically (Pay‑As‑You‑Earn). If you’re freelance, you’ll need to make quarterly prepayments.

## Country‑Specific Basics

### Germany
- **Tax classes** (Lohnsteuerklasse): Class I (single), Class III/V (married). Choose correctly to optimize monthly take‑home.
- **Solidarity surcharge** (Soli): 5.5% of income tax, but phased out for most middle‑income earners.
- **Church tax** (Kirchensteuer): 8–9% of income tax if you’re registered as Catholic/Protestant. You can opt out by deregistering.
- **Deadline**: Tax returns due July 31 of the following year (extensions possible).

### Spain
- **Autónomo** (freelancer) fee: Flat monthly social security contribution (€300–€600) regardless of income.
- **IRPF**: Progressive rates from 19% to 47%. Employers withhold ~15% for employees.
- **Beckham Law**: Special tax regime for foreign hires (flat 24% on income up to €600k). Must apply within 6 months of arrival.
- **Deadline**: June 30 for the previous tax year.

### Portugal
- **NHR regime** (Non‑Habitual Resident): 20% flat tax on certain professional income (IT, research, etc.) for 10 years. Must apply.
- **Standard rates**: 14.5–48% progressive.
- **Social security**: 11% from employee, 23.75% from employer.
- **Deadline**: April 30.

### United Kingdom
- **Personal allowance**: First £12,570 (approx €14,500) tax‑free.
- **Basic rate**: 20% on income up to £50,270.
- **Higher rate**: 40% up to £150,000.
- **Additional rate**: 45% above £150,000.
- **Deadline**: January 31 following the tax year (which ends April 5).

## Deductions You Might Be Missing

Even if you use a tax advisor, they might not know your full situation. Common deductible expenses for expats:

- **Moving costs**: Flights, shipping, temporary accommodation (often deductible in the first year).
- **Home office**: If you work remotely, a portion of rent, utilities, internet.
- **Professional development**: Language courses, certifications, conferences related to your job.
- **Health insurance premiums** (if not already covered by employer).
- **Donations to registered charities** (keep receipts).
- **Costs of managing investments** (advisor fees, platform fees).

**Keep receipts digitally** (take photos, store in Google Drive). Label them by category and year.

## The Tax Estimator Template

We’ve included a simple tax estimator spreadsheet. It gives you a rough idea of what you might owe based on your income and country.

**Important**: This is for estimation only. Actual tax liability depends on many factors. Use it to plan, not to file.

## When to Hire a Tax Advisor

Consider hiring a professional if:
- You have income from multiple countries
- You’re freelance or self‑employed
- You’ve sold property or investments
- You’re eligible for special regimes (NHR, Beckham Law) and need help applying
- You’ve been in the country more than 3 years and your situation is stable

**How to find a good advisor**:
- Ask other expats in local Facebook groups
- Look for English‑speaking advisors with expat experience
- Compare fees (some charge per hour, some per return)
- Check reviews on Google or Trustpilot

## What If You Made a Mistake?

If you realize you missed a deduction or filed incorrectly:
- **Most countries allow amendments** within 3–4 years.
- **Penalties** are often lower if you self‑correct before an audit.
- **Get help** from a professional to fix it—peace of mind is worth the fee.

## Action Steps This Month
1. **Determine your tax residency** (check local rules).
2. **Gather your income documents** (payslips, freelance invoices, bank statements).
3. **List potential deductions** (use the checklist in the template).
4. **Estimate your tax liability** using our template.
5. **Decide** whether to file yourself or hire help.

Taxes are a chore, but they’re manageable. Next chapter, we’ll tackle banking and currency—how to keep more of your money when moving it across borders.