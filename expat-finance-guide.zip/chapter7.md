# 7. Simple Investing for Beginners

Investing is how you turn saved euros into future wealth. You don’t need to be a stock‑picking genius—you just need a simple, automated system.

This chapter covers:
- What ETFs are and why they’re perfect for beginners
- Robo‑advisors available in Europe
- How much to start with
- Common mistakes to avoid

## Why Expats Should Invest (Even with Modest Income)

1. **Inflation eats cash.** At 2% inflation, €10,000 today will be worth €9,800 in a year if left in a checking account.
2. **Compound growth works best over time.** Starting at 30 with €100/month can grow to €100,000+ by 60.
3. **You might not qualify for a full state pension.** Building a private pension is essential.
4. **Investing forces you to think long‑term,** which reduces money stress.

## The Golden Rule: Invest Only What You Won’t Need for 5+ Years

The stock market goes up and down. If you need the money for a visa deposit next year, keep it in savings. Invest money you can afford to leave untouched for at least five years.

## What Are ETFs (Exchange‑Traded Funds)?

An ETF is a basket of hundreds or thousands of stocks (or bonds) that trades like a single stock.

**Example:** The Vanguard FTSE All‑World ETF (VWCE) holds shares in about 3,700 companies across developed and emerging markets. When you buy one share, you own a tiny piece of all those companies.

**Why ETFs are great for beginners:**
- **Diversification:** One ETF spreads your risk across many companies.
- **Low cost:** Annual fees as low as 0.12% (vs. 1–2% for actively managed funds).
- **Transparency:** You always know what you own.
- **Liquidity:** You can buy and sell any day the market is open.

## The One‑ETF Portfolio (If You Want to Keep It Super Simple)

Buy **VWCE** (Vanguard FTSE All‑World) or **IWDA** (iShares Core MSCI World) and hold it forever. That’s it. You’re globally diversified, low‑cost, and set for decades.

**How to buy:**
1. Open a brokerage account (see below).
2. Transfer money.
3. Search for the ETF ticker (VWCE).
4. Buy as many shares as you can afford (even fractional shares).
5. Set up automatic monthly purchases (if your broker supports it).

## Robo‑Advisors: Let the Robots Do It

If you don’t want to think about ETFs at all, use a robo‑advisor. They ask you questions about your risk tolerance, then build and manage a portfolio for you.

### Popular Robo‑Advisors in Europe

| Provider | Minimum | Fees | Best For |
|----------|---------|------|----------|
| **Trade Republic** | €1 | €0 trading fees + ETF internal fees (~0.2%) | Beginners who want flexibility (also offers savings interest). |
| **Scalable Capital** | €1 | 0.75% p.a. on managed portfolio (first €10,000 free) | Hands‑off investors who want a fully managed portfolio. |
| **ETFmatic** | €50 | 0.48% p.a. | Low‑cost automated investing across Europe. |
| **Moneyfarm** | €1 | 0.75–1.0% p.a. | UK/Italy focused, with human advisor access. |

**Recommendation:** Start with Trade Republic—it’s free to buy ETFs, and you can set up a savings plan for as little as €10/month.

## How Much to Start With

You can start with **€50**.

**Typical progression:**
1. Month 1: €50 into VWCE.
2. Month 2: Another €50.
3. After 6 months: Increase to €100/month if possible.
4. Whenever you get a raise or bonus, increase your monthly investment by half of the raise.

**Example:** Salary increases by €200/month → increase investments by €100/month.

## Tax Considerations for Investors in Europe

Taxes on investments vary widely by country. Key concepts:

- **Capital gains tax:** Tax on profits when you sell. In Germany, it’s 26.375% (including solidarity surcharge). In the UK, it’s 10–20% depending on income.
- **Dividend tax:** Tax on dividends paid by stocks/ETFs. Often withheld at source.
- **Tax‑free allowances:** Many countries have an annual allowance (e.g., €1,000 in Germany, £6,000 in the UK) below which you pay no capital gains tax.

**What to do:**
1. **Check your country’s rules** (consult a tax advisor if unsure).
2. **Use a tax‑efficient account** if available (e.g., ISA in the UK, Riester in Germany).
3. **Keep records** of every purchase (date, amount, price) for tax reporting.

## Common Investing Mistakes to Avoid

1. **Trying to time the market.** Nobody knows when it will go up or down. Invest regularly (monthly) regardless.
2. **Chasing “hot” stocks.** Meme stocks, crypto hype—ignore the noise.
3. **Checking your portfolio daily.** It will drive you crazy. Check once a quarter.
4. **Selling during a downturn.** The market always recovers eventually. Hold tight.
5. **Paying high fees.** Avoid active mutual funds with >1% annual fees.

## Your First Investment: Step‑by‑Step

1. **Open a brokerage account** (Trade Republic, Degiro, or your local bank’s investment platform).
2. **Verify your identity** (passport, proof of address).
3. **Transfer €50–€100** from your bank.
4. **Search for VWCE** (or the ETF your robo‑advisor recommends).
5. **Buy one share** (or set up a monthly savings plan).
6. **Set a calendar reminder** to buy more next month.

That’s it. You’re an investor.

## Action Steps This Month

1. **Open a brokerage account** (if you don’t have one).
2. **Invest €50** in a global ETF (VWCE or equivalent).
3. **Set up a monthly savings plan** for €50 (or whatever you can afford).
4. **Read one article** about long‑term investing (recommended: Mr. Money Mustache, The Simple Path to Wealth).

Next, we’ll look at insurance—what you need and what you can skip.