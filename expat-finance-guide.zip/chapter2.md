# 2. The Expat Financial Health Checklist

Before diving into budgets and spreadsheets, let’s assess where you stand right now. This checklist covers the five pillars of financial health for expats. Don’t worry if you’re missing some—that’s what the rest of the book will help you fix.

## Pillar 1: Emergency Fund
**Goal:** 3–6 months of essential expenses in a separate, accessible account.

### Why it’s different for expats:
- Your support network is smaller. If you lose your job or get sick, family might be thousands of miles away.
- Visa requirements can tie you to employment. No job sometimes means no right to stay.
- Repatriation costs (a flight home) can be steep.

### How to calculate:
1. List your **essential monthly expenses**: rent, utilities, health insurance, groceries, minimum debt payments.
2. Multiply by 3 (minimum) or 6 (comfortable).
3. Keep this money in a **high‑yield savings account** in euros (or local currency). Not in your checking account, not in crypto, not in stocks.

### Where to keep it (EU options):
- **Trade Republic** (4% p.a. on uninvested cash, up to €50k, Germany‑based)
- **Bunq** (easy multi‑currency accounts, Dutch bank)
- **Revolut** (vaults with interest, but check terms)
- **Local bank savings account** (often low interest, but safe)

## Pillar 2: Cash Flow Visibility
**Goal:** You know exactly how much money comes in and goes out each month, in every currency you use.

### The expat challenge:
- Income in one currency, expenses in another.
- Irregular income if you’re freelancing or contracting.
- Bank fees eating into transfers.

### Quick audit (do this now):
1. Open your bank statements from the last three months.
2. Categorize every transaction into:
   - **Fixed essentials** (rent, insurance, utilities)
   - **Variable essentials** (groceries, transport, healthcare)
   - **Discretionary** (eating out, travel, hobbies)
   - **Savings & investments**
3. Note the **average monthly total** for each category.

If you can’t do this in under 20 minutes, you need the tracking system we’ll build in Chapter 3.

## Pillar 3: Debt Management
**Goal:** No high‑interest debt (credit cards, payday loans). A plan for low‑interest debt (student loans, car financing).

### European context:
- Credit card interest rates are generally lower than in the US (often 12–18% vs 20–30%).
- Consumer debt is less normalized—carrying a balance is seen as risky.
- **Important:** Some countries require debt clearance for visa renewals.

### Action steps:
1. List all debts: balance, interest rate, minimum payment.
2. Prioritize by interest rate (highest first).
3. Set up automatic minimum payments to avoid fees.
4. Allocate any extra cash to the highest‑interest debt.

## Pillar 4: Insurance Coverage
**Goal:** You have the legally required insurance and the optional coverage that makes sense for your risk tolerance.

### Must‑haves (varies by country):
- **Health insurance** (mandatory in most EU countries)
- **Liability insurance** (Haftpflichtversicherung in Germany—€60/year, saves thousands)
- **Household contents insurance** (if you rent or own)

### Nice‑to‑haves:
- **Travel insurance** (if you visit home frequently)
- **Income protection** (if you’re freelance)

### Check:
- Are you **over‑insured**? Some employers provide extensive coverage you might not need to duplicate.
- Are you **under‑insured**? A single liability claim could wipe out your savings.

## Pillar 5: Retirement Planning
**Goal:** You’re contributing to a pension plan—state, private, or both.

### The reality:
- State pensions in Europe are often based on contributions over decades. As an expat, you might not qualify for full benefits.
- The earlier you start a private pension, the less you need to contribute monthly.

### What to do today:
1. Check your **state pension entitlement** (via local tax office or online portal).
2. If your employer offers a **company pension**, enroll—especially if they match contributions.
3. Open a **private pension plan** (we’ll cover options in Chapter 7) and set up a small monthly deposit (even €50/month).

## Your Current Score
Give yourself 1 point for each pillar where you feel confident (you have the system in place).  
0–2 points = We’ll build the foundation together.  
3–4 points = You’re ahead of most—let’s optimize.  
5 points = This book will still help you streamline and invest.

Now, let’s move to the practical system that ties all five pillars together: your monthly budget.