# Expat Finance Guide – MVP Launch

## Product: "Master Your Finances in Europe"
- **Price**: €97 one-time
- **Format**: PDF ebook + 3 spreadsheet templates + Telegram community
- **Target**: Expats/residents in Europe (age 25–45)
- **Language**: English

## Current Status (20:20, 2026‑04‑20)
- **Ebook**: 3 chapters written (out of ~15 planned), outline complete
- **Templates**: 3 CSV templates ready (monthly budget, expense tracker, tax estimator)
- **Landing page**: HTML static page for lead capture (free budget template)
- **Sales page**: Full sales copy HTML page
- **Email sequence**: 3 emails written (welcome, tips, offer)
- **Marketing content**: 2 Reddit posts drafted (value‑first approach)
- **Funnel**: Simulated (lead capture → email sequence → sales page → checkout)

## Next Actions Needed
1. **Decision**: Finish ebook (4‑6 hours) or launch MVP with current 3 chapters + promise of updates?
2. **Technical setup**:
   - Register domain (expatfinanceguide.com ?)
   - Set up Carrd/ConvertKit for lead capture
   - Set up Stripe for payments
   - Host PDFs and templates (Google Drive/Dropbox)
   - Create Telegram community
3. **Marketing launch**:
   - Post Reddit content (monitor rules, avoid spam)
   - Consider Facebook groups for expats
   - Potential partnership with tax advisors for affiliates

## Costs (Monthly)
- Carrd Pro: €19/mo
- ConvertKit Free (up to 1000 subscribers)
- Stripe fees (1.4% + €0.25 per transaction)
- Domain: ~€10/year
- Total initial: < €50

## Risk
- Low capital requirement
- Refund guarantee reduces buyer risk
- Organic marketing reduces ad spend

## Success Metrics
- First sale within 24h of launch
- 10+ leads from Reddit posts
- Conversion rate > 1% from lead to sale

## Notes
- Founder gave full autonomy
- Capital constraints: avoid paid ads
- Focus on organic, value‑first approach
- Goal: first victory (first sale) to validate system